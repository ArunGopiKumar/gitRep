sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel"
], function(Controller,MessageBox,JSONModel) {
	"use strict";
	return Controller.extend("com.sap.qrscanner.controller.App", {
		
	});
});
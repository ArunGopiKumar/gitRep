sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/m/Dialog",
	"../custom/VideoPlayer"
], function(Controller, MessageBox, MessageToast, JSONModel, Dialog, VideoPlayer) {
	"use strict";

	return Controller.extend("com.sap.qrscanner.controller.Home", {
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Home").attachPatternMatched(function(oEvent){
			}, this);
		},
		
		scan:function(){
			var scanDialog = new Dialog({
				title: "Scan your QR here..",
				content:[
					new sap.m.VBox("ScannerContainer",{
						width:"25rem",
						height:"18.9rem",
						items:[ new VideoPlayer("videoPlayer") ]
					})
				],
				afterClose:function(){
					scanDialog.destroy();
				}
			});
			
			scanDialog.open();
			jQuery.sap.delayedCall(1000, this, function(){
				
				function success(stream){
				    var videoPlayer =sap.ui.getCore().byId("videoPlayer").getDomRef();
				    videoPlayer.srcObject = stream;
				    videoPlayer.play();
				    
				    window.qrcode.callback = function(data){
				    	if(data !== "error decoding QR Code" && data !== "Failed to load the image"){
				    		MessageToast.show(data);
				    	}
				    };
				    
				    var gCanvas = document.createElement('canvas');
				    jQuery.sap.intervalCall(1000,this,function(){
				    	
					    gCanvas.width = $(videoPlayer).width();
					    gCanvas.height = $(videoPlayer).height();
					    var gCtx = gCanvas.getContext("2d");
					    gCtx.clearRect(0, 0, $(videoPlayer).width(), $(videoPlayer).height());
				    	gCtx.drawImage(videoPlayer,0,0,$(videoPlayer).width(), $(videoPlayer).height());
				    	qrcode.decode(gCanvas.toDataURL())
				    });
				    
				}
				if(navigator.mediaDevices.getUserMedia) {
					navigator.mediaDevices.getUserMedia({video: { facingMode: "environment" }, audio: false}).
					then(function(stream){
						success(stream);
					}).catch(function(error){
						error(error)
					});
					}
					else if(navigator.getUserMedia) {
						navigator.getUserMedia({video: { facingMode: "environment" }, audio: false}, success, error);
					}
					else
					if(navigator.webkitGetUserMedia) {
						navigator.webkitGetUserMedia({video:{ facingMode: "environment" }, audio: false}, success, error);
					}
			});
		}
	});
});
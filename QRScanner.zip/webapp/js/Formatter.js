sap.ui.define([
], function(JSONModel, Device) {
	"use strict";
	return {
		example: function(name) {
			return "Hello " + name;
		}
	};
});
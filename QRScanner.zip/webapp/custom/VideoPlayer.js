sap.ui.define(

	["sap/ui/core/Control"],

	function (Control) {

		var control = Control.extend("com.sap.qrscanner.custom.VideoPlayer", {

			metadata: {

				properties: {

					src: {

						type: "string",

						defaultValue: ""

					},

					width: {

						type: "sap.ui.core.CSSSize",

						group: "Appearance",

						defaultValue: "100%"

					}

				}

			},
			renderer: function (oRm, oControl) {
				oRm.write('<video oncontextmenu="return false;" controls="false" controlsList="nodownload" style="width:' + oControl.getWidth() +
					';max-height: calc(100vh - 18rem);"');
				oRm.writeControlData(oControl); //ui5 trackings data, outputs sId, absolutely mandatory
				oRm.writeClasses(oControl); //allows the class="" attribute to work correctly
				oRm.write(">");
				oRm.write("<source src='" + oControl.getSrc() + "' type='video/mp4'>");
				oRm.write("</video>");
			}
		});
		return control;
	});